
$(document).ready(function(){
    $(".grande").click(function(){
        $('.modal').addClass("active");
        $('.modal-overlay').addClass("active");
    });
});
